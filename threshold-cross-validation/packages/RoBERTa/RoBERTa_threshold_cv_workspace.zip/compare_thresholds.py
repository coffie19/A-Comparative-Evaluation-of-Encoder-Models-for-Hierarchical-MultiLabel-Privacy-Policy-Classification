#!/usr/bin/env python
"""Combine completed four-model held-out threshold results."""
from __future__ import annotations
import argparse
import json
from pathlib import Path

MODELS = ["BERT", "RoBERTa", "LegalBERT", "PrivBERT"]
METHODS = [("fixed_0_5", "Fixed 0.50"), ("global_cv", "Global CV threshold"),
           ("per_category_cv", "Per-category CV thresholds")]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-root", type=Path, required=True)
    args = parser.parse_args()
    root = args.output_root.expanduser().resolve() / "full"
    results = {}
    for model in MODELS:
        path = root / model / "heldout_results.json"
        if not path.is_file():
            raise FileNotFoundError(f"Complete the threshold notebook for {model}: {path}")
        results[model] = json.loads(path.read_text(encoding="utf-8"))["aggregate"]
    lines = ["# Four-model threshold comparison", "",
             "Thresholds were selected exclusively from five-fold out-of-fold predictions on the original 65 training policies. "
             "The table evaluates those fixed choices on the untouched 50-policy set across the five completed main-study seeds.", ""]
    for key, label in METHODS:
        lines += [f"## {label}", "", "| Model | Category Macro-F1 mean ± sample SD | Data Retention F1 mean ± sample SD |",
                  "|---|---:|---:|"]
        ordered = sorted(MODELS, key=lambda model: results[model][key]["category_macro_f1"]["mean"], reverse=True)
        for model in ordered:
            macro = results[model][key]["category_macro_f1"]
            retention = results[model][key]["data_retention"]["f1"]
            lines.append(f"| {model} | {macro['mean']:.6f} ± {macro['std']:.6f} | {retention['mean']:.6f} ± {retention['std']:.6f} |")
        lines.append("")
    fixed_rank = sorted(MODELS, key=lambda model: results[model]["fixed_0_5"]["category_macro_f1"]["mean"], reverse=True)
    global_rank = sorted(MODELS, key=lambda model: results[model]["global_cv"]["category_macro_f1"]["mean"], reverse=True)
    per_rank = sorted(MODELS, key=lambda model: results[model]["per_category_cv"]["category_macro_f1"]["mean"], reverse=True)
    lines += ["## Direct answers", "",
              f"- Category ranking at 0.50: {' > '.join(fixed_rank)}.",
              f"- Category ranking with the global cross-validated threshold: {' > '.join(global_rank)}.",
              f"- Category ranking with per-category cross-validated thresholds: {' > '.join(per_rank)}.",
              f"- The primary ranking conclusion {'survives' if fixed_rank == global_rank else 'changes'} under the global-threshold experiment.",
              "- Data Retention precision, recall and F1 for every seed are retained in each model's heldout_results.json.", "",
              "The global analysis is primary because it selects one parameter. The ten-threshold per-category analysis is secondary and has greater selection variance."]
    report = root / "threshold_comparison.md"
    report.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(report)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
