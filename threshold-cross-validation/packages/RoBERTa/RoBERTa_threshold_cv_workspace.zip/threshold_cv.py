#!/usr/bin/env python
"""Policy-grouped five-fold threshold selection for OPP-115 category models.

The 65 original training policies are partitioned into five folds of 13 policies.
Each policy is held out once. Global and per-category thresholds are selected from
the resulting out-of-fold probabilities only. The untouched 50-policy evaluation
set is scored only after threshold selection.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib
import json
import math
import os
from pathlib import Path
import random
import statistics
import sys
from typing import Any, Iterable, Sequence

import numpy as np

FOLD_SEEDS = [17011, 29023, 41047, 53069, 65089]
GRID = np.round(np.arange(0.05, 0.951, 0.01), 2)


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n", encoding="utf-8")
    tmp.replace(path)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def fingerprint(value: Any) -> str:
    payload = json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def f1_positive(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    y_true = np.asarray(y_true, dtype=np.int64)
    y_pred = np.asarray(y_pred, dtype=np.int64)
    tp = int(np.sum((y_true == 1) & (y_pred == 1)))
    fp = int(np.sum((y_true == 0) & (y_pred == 1)))
    fn = int(np.sum((y_true == 1) & (y_pred == 0)))
    denominator = 2 * tp + fp + fn
    return 0.0 if denominator == 0 else 2 * tp / denominator


def label_metrics(y_true: np.ndarray, probabilities: np.ndarray, thresholds: Sequence[float]) -> dict[str, Any]:
    thresholds_array = np.asarray(thresholds, dtype=float)
    predictions = (probabilities >= thresholds_array[None, :]).astype(np.int64)
    per_label = []
    for index in range(y_true.shape[1]):
        truth = y_true[:, index]
        pred = predictions[:, index]
        tp = int(np.sum((truth == 1) & (pred == 1)))
        fp = int(np.sum((truth == 0) & (pred == 1)))
        fn = int(np.sum((truth == 1) & (pred == 0)))
        precision = 0.0 if tp + fp == 0 else tp / (tp + fp)
        recall = 0.0 if tp + fn == 0 else tp / (tp + fn)
        f1 = 0.0 if 2 * tp + fp + fn == 0 else 2 * tp / (2 * tp + fp + fn)
        per_label.append(dict(tp=tp, fp=fp, fn=fn, precision=precision, recall=recall, f1=f1,
                              positive_support=int(truth.sum()), threshold=float(thresholds_array[index])))
    return dict(macro_f1=float(np.mean([row["f1"] for row in per_label])), per_label=per_label)


def _best(candidates: Iterable[tuple[float, float]]) -> tuple[float, float]:
    # Maximise F1; ties prefer the threshold closest to 0.5, then the lower threshold.
    return max(candidates, key=lambda item: (item[1], -abs(item[0] - 0.5), -item[0]))


def choose_thresholds(y_true: np.ndarray, probabilities: np.ndarray) -> dict[str, Any]:
    labels = y_true.shape[1]
    global_candidates = []
    for threshold in GRID:
        score = label_metrics(y_true, probabilities, [float(threshold)] * labels)["macro_f1"]
        global_candidates.append((float(threshold), score))
    global_threshold, global_score = _best(global_candidates)
    per_category = []
    for index in range(labels):
        candidates = [
            (float(threshold), f1_positive(y_true[:, index], probabilities[:, index] >= threshold))
            for threshold in GRID
        ]
        threshold, score = _best(candidates)
        per_category.append(dict(threshold=threshold, oof_f1=score))
    return {
        "grid": dict(minimum=0.05, maximum=0.95, step=0.01, tie_break="closest to 0.5, then lower"),
        "baseline": label_metrics(y_true, probabilities, [0.5] * labels),
        "global_threshold": global_threshold,
        "global": label_metrics(y_true, probabilities, [global_threshold] * labels),
        "global_selection_macro_f1": global_score,
        "per_category": per_category,
        "per_category_result": label_metrics(y_true, probabilities, [row["threshold"] for row in per_category]),
    }


def make_policy_folds(examples: Sequence[Any], training_ids: Sequence[str], category_count: int) -> list[list[str]]:
    by_policy: dict[str, list[Any]] = {policy_id: [] for policy_id in training_ids}
    for example in examples:
        if example.policy_id in by_policy:
            by_policy[example.policy_id].append(example)
    if any(not rows for rows in by_policy.values()):
        missing = [key for key, rows in by_policy.items() if not rows]
        raise ValueError("Training policies without segment examples: " + ", ".join(missing))
    vectors = {}
    sizes = {}
    for policy_id, rows in by_policy.items():
        vectors[policy_id] = np.asarray([row.category_labels for row in rows], dtype=int).sum(axis=0)
        sizes[policy_id] = len(rows)
    totals = sum(vectors.values(), np.zeros(category_count, dtype=int))
    rarity = 1.0 / np.sqrt(np.maximum(totals, 1))
    order = sorted(training_ids, key=lambda policy_id: (
        -float(np.dot(vectors[policy_id], rarity)), -sizes[policy_id], policy_id.casefold()
    ))
    fold_ids: list[list[str]] = [[] for _ in range(5)]
    fold_support = [np.zeros(category_count, dtype=float) for _ in range(5)]
    fold_segments = [0] * 5
    target_support = totals / 5.0
    target_segments = sum(sizes.values()) / 5.0
    for policy_id in order:
        minimum_count = min(len(items) for items in fold_ids)
        candidates = [index for index, items in enumerate(fold_ids) if len(items) == minimum_count]
        def cost(index: int) -> tuple[float, int]:
            support = fold_support[index] + vectors[policy_id]
            support_cost = float(np.sum(((support - target_support) / np.maximum(target_support, 1.0)) ** 2))
            size_cost = ((fold_segments[index] + sizes[policy_id] - target_segments) / target_segments) ** 2
            return support_cost + 0.25 * size_cost, index
        selected = min(candidates, key=cost)
        fold_ids[selected].append(policy_id)
        fold_support[selected] += vectors[policy_id]
        fold_segments[selected] += sizes[policy_id]
    if [len(items) for items in fold_ids] != [13] * 5:
        raise AssertionError("Five-fold assignment must contain exactly 13 policies per fold")
    flattened = [item for fold in fold_ids for item in fold]
    if len(flattened) != len(set(flattened)) or set(flattened) != set(training_ids):
        raise AssertionError("Each training policy must occur in exactly one validation fold")
    return [sorted(items, key=str.casefold) for items in fold_ids]


def predict_categories(backend: Any, checkpoint: Path, examples: Sequence[Any], max_length: int,
                       batch_size: int, device_name: str) -> np.ndarray:
    import torch
    model, tokenizer, _schema, _metadata = backend.load_saved_classifier(
        checkpoint, device=device_name
    )
    device = torch.device(device_name)
    rows = []
    with torch.no_grad():
        for start in range(0, len(examples), batch_size):
            batch = examples[start:start + batch_size]
            encoded = tokenizer([item.text for item in batch], truncation=True, padding=True,
                                max_length=max_length, pad_to_multiple_of=8, return_tensors="pt")
            encoded = {key: value.to(device) for key, value in encoded.items()}
            category_logits, _attribute_logits = model(**encoded)
            rows.append(torch.sigmoid(category_logits).cpu().numpy())
    return np.concatenate(rows, axis=0)


def fold_summary(examples: Sequence[Any], fold_ids: Sequence[Sequence[str]], categories: Sequence[str]) -> list[dict[str, Any]]:
    result = []
    for index, ids in enumerate(fold_ids):
        selected = [item for item in examples if item.policy_id in set(ids)]
        support = np.asarray([item.category_labels for item in selected], dtype=int).sum(axis=0)
        result.append(dict(fold=index + 1, seed=FOLD_SEEDS[index], policies=len(ids), segments=len(selected),
                           category_support={name: int(value) for name, value in zip(categories, support)}))
    return result


def training_args(backend: Any, config: dict[str, Any], mode: str, data_dir: Path,
                  checkpoint_dir: Path, summary_file: Path, seed: int) -> argparse.Namespace:
    parser = backend.build_argument_parser()
    args = parser.parse_args([])
    selected = config["smoke"] if mode == "smoke" else config["full"]
    args.data_dir = data_dir
    args.model_name = selected["name"]
    args.model_revision = selected["revision"]
    args.output_dir = checkpoint_dir
    args.summary_file = summary_file
    args.max_length = 64 if mode == "smoke" else 384
    args.batch_size = 4 if mode == "smoke" else 8
    args.epochs = 5
    args.max_steps = 1 if mode == "smoke" else 0
    args.max_train_examples = 8 if mode == "smoke" else 0
    args.max_eval_examples = 32 if mode == "smoke" else 0
    args.learning_rate = 2.5e-5
    args.weight_decay = 0.01
    args.warmup_ratio = 0.1
    args.gradient_accumulation_steps = 4
    args.max_grad_norm = 1.0
    args.classifier_dropout = 0.15
    args.threshold = 0.5
    args.attribute_loss_weight = 1.0
    args.positive_weight_power = 0.5
    args.max_positive_weight = 10.0
    args.seed = seed
    args.num_workers = 0
    args.device = "cpu" if mode == "smoke" else "cuda"
    args.no_save = False
    args.overwrite_output_dir = True
    return args


def aggregate_main_results(rows: Sequence[dict[str, Any]], categories: Sequence[str]) -> dict[str, Any]:
    methods = ["fixed_0_5", "global_cv", "per_category_cv"]
    data_retention_index = list(categories).index("Data Retention")
    result: dict[str, Any] = {}
    for method in methods:
        macro_values = [row[method]["macro_f1"] for row in rows]
        retention = [row[method]["per_label"][data_retention_index] for row in rows]
        result[method] = dict(
            category_macro_f1=dict(mean=statistics.mean(macro_values), std=statistics.stdev(macro_values), n=len(rows), ddof=1),
            data_retention={field: dict(mean=statistics.mean(item[field] for item in retention),
                                        std=statistics.stdev(item[field] for item in retention), n=len(rows), ddof=1)
                            for field in ("precision", "recall", "f1")},
        )
    return result


def write_oof(path: Path, examples: Sequence[Any], probabilities: np.ndarray, folds: Sequence[int], categories: Sequence[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as stream:
        for example, probs, fold in zip(examples, probabilities, folds):
            row = dict(policy_id=example.policy_id, segment_id=example.segment_id, fold=fold,
                       gold={name: int(value) for name, value in zip(categories, example.category_labels)},
                       probabilities={name: float(value) for name, value in zip(categories, probs)})
            stream.write(json.dumps(row, sort_keys=True) + "\n")


def write_report(path: Path, model: str, selection: dict[str, Any], categories: Sequence[str],
                 main: dict[str, Any] | None) -> None:
    retention_index = list(categories).index("Data Retention")
    per_thresholds = [row["threshold"] for row in selection["per_category"]]
    lines = [f"# {model}: training-side five-fold threshold experiment", "",
             "The original 65 training policies were divided into five disjoint folds of 13 policies. "
             "Every training segment received one out-of-fold probability from a model that did not train on its policy. "
             "The 50-policy evaluation set was not used to choose thresholds.", "",
             "## Selected thresholds", "",
             f"- Global threshold: **{selection['global_threshold']:.2f}**",
             f"- Out-of-fold category Macro-F1 at 0.50: **{selection['baseline']['macro_f1']:.6f}**",
             f"- Out-of-fold category Macro-F1 at the global threshold: **{selection['global']['macro_f1']:.6f}**",
             f"- Data Retention per-category threshold: **{per_thresholds[retention_index]:.2f}**", "",
             "| Category | Selected threshold | Out-of-fold F1 |", "|---|---:|---:|"]
    for name, row in zip(categories, selection["per_category"]):
        lines.append(f"| {name} | {row['threshold']:.2f} | {row['oof_f1']:.6f} |")
    if main is None:
        lines += ["", "## Held-out evaluation", "",
                  "Pending: completed five-seed checkpoints were not supplied at this path. "
                  "Thresholds have been selected, but no claim about final rankings or Data Retention is made yet."]
    else:
        lines += ["", "## Untouched 50-policy evaluation across five completed seeds", "",
                  "| Decision rule | Category Macro-F1 mean ± sample SD | Data Retention F1 mean ± sample SD |",
                  "|---|---:|---:|"]
        labels = [("fixed_0_5", "Fixed 0.50"), ("global_cv", "Global CV threshold"),
                  ("per_category_cv", "Per-category CV thresholds")]
        for key, label in labels:
            macro = main[key]["category_macro_f1"]
            retention = main[key]["data_retention"]["f1"]
            lines.append(f"| {label} | {macro['mean']:.6f} ± {macro['std']:.6f} | {retention['mean']:.6f} ± {retention['std']:.6f} |")
        lines += ["", "The global threshold is the primary sensitivity analysis because it introduces one selected parameter. "
                  "Per-category thresholds introduce ten selected parameters and are reported as a secondary analysis. "
                  "Model rankings must be compared in the combined four-model report."]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def run(args: argparse.Namespace) -> int:
    model_dir = args.model_dir.expanduser().resolve()
    data_dir = (args.data_dir or model_dir / "data" / "opp115").expanduser().resolve()
    output_root = args.output_root.expanduser().resolve()
    config = read_json(model_dir / "model_config.json")
    sys.path.insert(0, str(model_dir))
    backend = importlib.import_module(config["backend"])
    hierarchy = importlib.import_module("opp115_hierarchy")
    train_ids, test_ids = hierarchy.fixed_policy_split(data_dir / "annotations")
    full_schema = hierarchy.derive_hierarchy_schema(data_dir / "annotations", train_ids)
    full_examples = backend.load_segment_examples(data_dir, full_schema)
    folds = make_policy_folds(full_examples, train_ids, len(hierarchy.HIGH_LEVEL_CATEGORIES))
    model_output = output_root / args.mode / config["model"]
    model_output.mkdir(parents=True, exist_ok=True)
    specification = dict(format_version=1, model=config["model"], mode=args.mode,
                         base_model=config["smoke" if args.mode == "smoke" else "full"],
                         fold_seeds=FOLD_SEEDS, train_policy_ids=list(train_ids), untouched_test_policy_ids=list(test_ids),
                         folds=folds, threshold_grid=dict(minimum=0.05, maximum=0.95, step=0.01),
                         training=dict(epochs=5, batch_size=4 if args.mode == "smoke" else 8,
                                       gradient_accumulation_steps=4, learning_rate=2.5e-5, weight_decay=0.01,
                                       warmup_ratio=0.1, classifier_dropout=0.15, threshold_during_training=0.5),
                         selection_data="out-of-fold predictions from the original 65 training policies only")
    spec_path = model_output / "study_specification.json"
    if spec_path.exists() and read_json(spec_path) != specification:
        raise ValueError("Existing threshold study has different settings; choose a new output root")
    write_json(spec_path, specification)
    write_json(model_output / "fold_summary.json",
               fold_summary(full_examples, folds, hierarchy.HIGH_LEVEL_CATEGORIES))
    if args.prepare_only:
        print("PREPARED; no training performed:", spec_path)
        return 0
    try:
        import torch
    except ImportError as exc:
        raise RuntimeError("Install the model workspace requirements") from exc
    if args.mode == "full" and not torch.cuda.is_available():
        raise RuntimeError("Full five-fold training requires a CUDA GPU")
    oof_records = []
    for fold_index, validation_ids in enumerate(folds):
        fold_number = fold_index + 1
        seed = FOLD_SEEDS[fold_index]
        fold_dir = model_output / f"fold_{fold_number}"
        checkpoint = fold_dir / "checkpoint"
        summary_path = fold_dir / "summary.json"
        prediction_path = fold_dir / "validation_predictions.npz"
        complete_path = fold_dir / "complete.json"
        fold_train_ids = tuple(policy_id for policy_id in train_ids if policy_id not in set(validation_ids))
        fold_schema = hierarchy.derive_hierarchy_schema(data_dir / "annotations", fold_train_ids)
        fold_examples = backend.load_segment_examples(data_dir, fold_schema)
        train_examples = [item for item in fold_examples if item.policy_id in set(fold_train_ids)]
        validation_examples = [item for item in fold_examples if item.policy_id in set(validation_ids)]
        if complete_path.exists():
            receipt = read_json(complete_path)
            if receipt.get("specification_sha256") != fingerprint(specification) or receipt.get("seed") != seed:
                raise ValueError(f"Fold {fold_number} completion receipt belongs to a different study")
            if receipt.get("prediction_sha256") != sha256(prediction_path):
                raise ValueError(f"Fold {fold_number} predictions changed after completion")
            print(f"Verified completed fold {fold_number}; reusing.", flush=True)
        else:
            fold_dir.mkdir(parents=True, exist_ok=True)
            train_args = training_args(backend, config, args.mode, data_dir, checkpoint, summary_path, seed)
            fold_result = backend.run_classification(train_args, fold_examples, train_examples, validation_examples,
                                                     fold_train_ids, validation_ids, fold_schema)
            backend.write_summary(fold_result, summary_path)
            probabilities = predict_categories(backend, checkpoint, validation_examples,
                                                train_args.max_length, train_args.batch_size, train_args.device)
            truths = np.asarray([item.category_labels for item in validation_examples], dtype=np.int64)
            np.savez_compressed(prediction_path, probabilities=probabilities, truths=truths,
                                policy_ids=np.asarray([item.policy_id for item in validation_examples]),
                                segment_ids=np.asarray([item.segment_id for item in validation_examples]))
            write_json(complete_path, dict(fold=fold_number, seed=seed,
                                           specification_sha256=fingerprint(specification),
                                           summary_sha256=sha256(summary_path), prediction_sha256=sha256(prediction_path)))
        data = np.load(prediction_path)
        for row_index in range(len(data["policy_ids"])):
            oof_records.append((str(data["policy_ids"][row_index]), str(data["segment_ids"][row_index]),
                                fold_number, data["truths"][row_index], data["probabilities"][row_index]))
    oof_records.sort(key=lambda item: (item[0].casefold(), int(item[1]) if item[1].isdigit() else item[1]))
    if len(oof_records) != 2352 or len({(row[0], row[1]) for row in oof_records}) != 2352:
        raise AssertionError("Out-of-fold predictions must cover all 2,352 training segments exactly once")
    y_true = np.stack([row[3] for row in oof_records])
    probabilities = np.stack([row[4] for row in oof_records])
    selection = choose_thresholds(y_true, probabilities)
    selection["categories"] = list(hierarchy.HIGH_LEVEL_CATEGORIES)
    selection["oof_segments"] = len(oof_records)
    selection["oof_policies"] = 65
    write_json(model_output / "selected_thresholds.json", selection)
    ordered_examples = []
    lookup = {(item.policy_id, item.segment_id): item for item in full_examples}
    for row in oof_records:
        ordered_examples.append(lookup[(row[0], row[1])])
    write_oof(model_output / "oof_predictions.jsonl", ordered_examples, probabilities,
              [row[2] for row in oof_records], hierarchy.HIGH_LEVEL_CATEGORIES)
    main_aggregate = None
    if args.mode == "full" and args.main_study_root:
        main_model_root = args.main_study_root.expanduser().resolve() / "full" / config["model"]
        test_examples = [item for item in full_examples if item.policy_id in set(test_ids)]
        per_seed = []
        global_thresholds = [selection["global_threshold"]] * len(hierarchy.HIGH_LEVEL_CATEGORIES)
        per_category_thresholds = [row["threshold"] for row in selection["per_category"]]
        checkpoints = [(seed, main_model_root / f"seed_{seed}" / "checkpoint") for seed in FOLD_SEEDS]
        missing_checkpoints = [checkpoint for _seed, checkpoint in checkpoints if not checkpoint.is_dir()]
        if missing_checkpoints:
            print("WARNING: Threshold selection completed, but held-out evaluation was skipped because "
                  "the following main-study checkpoint folders are missing:", flush=True)
            for checkpoint in missing_checkpoints:
                print(" -", checkpoint, flush=True)
            print("Copy the checkpoint folders to the listed locations and rerun this cell. "
                  "The five completed folds will be verified and reused.", flush=True)
        else:
            for seed, checkpoint in checkpoints:
                probs = predict_categories(backend, checkpoint, test_examples, 384, 8, "cuda")
                truths = np.asarray([item.category_labels for item in test_examples], dtype=np.int64)
                per_seed.append(dict(seed=seed,
                                     fixed_0_5=label_metrics(truths, probs, [0.5] * len(hierarchy.HIGH_LEVEL_CATEGORIES)),
                                     global_cv=label_metrics(truths, probs, global_thresholds),
                                     per_category_cv=label_metrics(truths, probs, per_category_thresholds)))
            main_aggregate = aggregate_main_results(per_seed, hierarchy.HIGH_LEVEL_CATEGORIES)
            write_json(model_output / "heldout_results.json", dict(model=config["model"], per_seed=per_seed,
                                                                    aggregate=main_aggregate,
                                                                    test_policies=50, test_segments=len(test_examples)))
    write_report(model_output / "report.md", config["model"], selection,
                 hierarchy.HIGH_LEVEL_CATEGORIES, main_aggregate)
    write_json(model_output / "status.json", dict(status="complete", reportable=main_aggregate is not None,
                                                   folds=5, oof_policies=65, oof_segments=2352,
                                                   heldout_evaluation_completed=main_aggregate is not None))
    print("Completed:", model_output / "report.md")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model-dir", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--data-dir", type=Path)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--main-study-root", type=Path,
                        help="Root containing full/MODEL/seed_SEED/checkpoint from the five-seed study")
    parser.add_argument("--mode", choices=("full", "smoke"), default="full")
    parser.add_argument("--prepare-only", action="store_true")
    return parser


if __name__ == "__main__":
    raise SystemExit(run(build_parser().parse_args()))
