#!/usr/bin/env python
"""Build a deterministic, self-contained BERT/OPP-115 ZIP."""

from __future__ import annotations

import hashlib
import json
import sys
import zipfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from opp115_hierarchy import (  # noqa: E402
    ATTRIBUTE_HEADS,
    HIGH_LEVEL_CATEGORIES,
    derive_hierarchy_schema,
    fixed_policy_split,
    load_raw_annotation_rows,
)


DATA_ROOT_CANDIDATES = (
    PROJECT_ROOT / "data" / "OPP-115_v1_0" / "OPP-115",
    PROJECT_ROOT / "data" / "opp115",
)
CANONICAL_DATA_ROOT = next(
    (candidate for candidate in DATA_ROOT_CANDIDATES if candidate.is_dir()),
    DATA_ROOT_CANDIDATES[0],
)
OUTPUT_DIR = PROJECT_ROOT / "colab_migration"
ARCHIVE_PATH = OUTPUT_DIR / "bert_opp115_colab_workspace.zip"
MANIFEST_PATH = OUTPUT_DIR / "bert_opp115_colab_workspace.manifest.json"
SHA256_PATH = OUTPUT_DIR / "bert_opp115_colab_workspace.zip.sha256"
ROOT_MANIFEST_PATH = PROJECT_ROOT / "workspace_manifest.json"

PROJECT_FILES = (
    "bert_opp115_colab.ipynb",
    "bert_opp115_pretraining.py",
    "bert_opp115_classification.py",
    "opp115_hierarchy.py",
    "opp115_policy_split.py",
    "opp115_csv_loader.py",
    "ml_layer_embeddings.py",
    "evaluation.py",
    "config.py",
    "requirements_colab_bert_opp115.txt",
    "requirements_bert_opp115.txt",
    "README_BERT_OPP115.md",
    "scripts/build_bert_opp115_colab_notebook.py",
    "scripts/build_bert_opp115_colab_workspace.py",
    "tests/test_evaluation_metrics.py",
    "tests/test_opp115_csv_loader.py",
    "tests/test_opp115_policy_split.py",
    "tests/test_opp115_hierarchy.py",
    "tests/test_bert_opp115_classification.py",
    "tests/test_bert_opp115_pretraining.py",
    "tests/test_bert_colab_bundle.py",
    "results/bert_opp115_hierarchy_data_summary.json",
    "results/bert_opp115_hierarchy_smoke_summary.json",
    "results/bert_opp115_pretraining_data_summary.json",
    "results/bert_opp115_pretraining_smoke_summary.json",
)

EXCLUDED_LOCAL_ONLY_CONTENT = (
    ".venv* and Python caches",
    "IDE, Git, Codex, and agent metadata",
    "logs and generated corpus.txt",
    "the superseded flat 20-label taxonomy and its legacy results",
    "legacy FastText and unrelated model-pipeline files",
    "prior models, checkpoints, and run directories",
    "duplicate OPP-115 representations outside annotations/sanitized_policies",
)


@dataclass(frozen=True)
class ArchiveInput:
    source: Path
    archive_name: str


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def normalized_archive_name(name: str) -> str:
    path = PurePosixPath(name.replace("\\", "/"))
    if path.is_absolute() or ".." in path.parts or not path.parts:
        raise ValueError(f"Unsafe archive path: {name!r}")
    return path.as_posix()


def collect_inputs() -> tuple[list[ArchiveInput], int, int]:
    inputs: list[ArchiveInput] = []
    for relative_name in PROJECT_FILES:
        source = PROJECT_ROOT / relative_name
        if not source.is_file():
            raise FileNotFoundError(f"Required project file is missing: {source}")
        inputs.append(
            ArchiveInput(source.resolve(), normalized_archive_name(relative_name))
        )

    annotations = sorted(
        (CANONICAL_DATA_ROOT / "annotations").glob("*.csv"),
        key=lambda path: (path.name.casefold(), path.name),
    )
    policies = sorted(
        (CANONICAL_DATA_ROOT / "sanitized_policies").glob("*.html"),
        key=lambda path: (path.name.casefold(), path.name),
    )
    if len(annotations) != 115 or len(policies) != 115:
        raise ValueError(
            "Expected canonical OPP-115 data with 115 annotation CSVs and 115 "
            f"sanitized HTML policies; found {len(annotations)} and {len(policies)}."
        )
    if [path.stem for path in annotations] != [path.stem for path in policies]:
        raise ValueError("Annotation and sanitized-policy IDs do not match")

    inputs.extend(
        ArchiveInput(
            path.resolve(),
            normalized_archive_name(f"data/opp115/annotations/{path.name}"),
        )
        for path in annotations
    )
    inputs.extend(
        ArchiveInput(
            path.resolve(),
            normalized_archive_name(f"data/opp115/sanitized_policies/{path.name}"),
        )
        for path in policies
    )
    dataset_readme = CANONICAL_DATA_ROOT / "readme.txt"
    if not dataset_readme.is_file():
        raise FileNotFoundError(f"OPP-115 attribution file is missing: {dataset_readme}")
    inputs.append(ArchiveInput(dataset_readme.resolve(), "data/opp115/readme.txt"))

    names = [item.archive_name for item in inputs]
    if len(names) != len(set(names)):
        raise ValueError("The workspace contains duplicate archive paths")
    return inputs, len(annotations), len(policies)


def deterministic_zip_info(name: str) -> zipfile.ZipInfo:
    info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = 0o100644 << 16
    return info


def _load_validated_data_summary(schema_hash: str) -> dict[str, object]:
    path = PROJECT_ROOT / "results" / "bert_opp115_hierarchy_data_summary.json"
    summary = json.loads(path.read_text(encoding="utf-8"))
    expected = {
        "corpus": "OPP-115",
        "task": "hierarchical fine-grained segment classification",
        "category_count": 10,
        "attribute_head_count": 20,
        "fine_grained_label_count": 138,
        "segments": 3792,
        "train_segments": 2352,
        "eval_segments": 1440,
        "train_policies": 65,
        "eval_policies": 50,
    }
    for field, expected_value in expected.items():
        if summary.get(field) != expected_value:
            raise ValueError(
                f"Hierarchy data summary has stale {field}: {summary.get(field)!r}"
            )
    if summary.get("label_schema", {}).get("schema_sha256") != schema_hash:
        raise ValueError("Hierarchy data summary has a stale schema hash")
    return summary


def build_workspace() -> dict[str, object]:
    inputs, annotation_count, policy_count = collect_inputs()
    annotations_dir = CANONICAL_DATA_ROOT / "annotations"
    train_policy_ids, eval_policy_ids = fixed_policy_split(
        annotations_dir, train_count=65, eval_count=50
    )
    hierarchy_schema = derive_hierarchy_schema(annotations_dir, train_policy_ids)
    hierarchy_manifest = hierarchy_schema.to_manifest()
    if (
        len(HIGH_LEVEL_CATEGORIES) != 10
        or len(ATTRIBUTE_HEADS) != 20
        or hierarchy_schema.flattened_value_count != 138
    ):
        raise ValueError("The canonical hierarchy must be 10 categories + 20 heads / 138 values")
    if tuple(train_policy_ids) != hierarchy_schema.training_policy_ids:
        raise ValueError("Hierarchy vocabulary was not derived from the exact training split")
    if len(train_policy_ids) != 65 or len(eval_policy_ids) != 50:
        raise ValueError("Canonical OPP-115 IDs do not form the exact 65/50 split")

    data_summary = _load_validated_data_summary(hierarchy_schema.schema_sha256)
    if data_summary.get("train_policy_ids") != list(train_policy_ids):
        raise ValueError("Data summary training policy IDs are stale")
    if data_summary.get("eval_policy_ids") != list(eval_policy_ids):
        raise ValueError("Data summary evaluation policy IDs are stale")
    annotation_rows = len(load_raw_annotation_rows(annotations_dir, strict=True))
    if annotation_rows != 23194:
        raise ValueError(f"Expected 23,194 annotation rows; found {annotation_rows}")

    file_records: list[dict[str, object]] = []
    for item in inputs:
        file_records.append(
            {
                "path": item.archive_name,
                "bytes": item.source.stat().st_size,
                "sha256": sha256_file(item.source),
            }
        )

    manifest: dict[str, object] = {
        "schema_version": 4,
        "workspace": "BERT OPP-115 Colab",
        "default_mode": "full",
        "default_run_pretraining": False,
        "task": "hierarchical_fine_grained_segment_classification",
        "classifier_output_directory": "bert-opp115-hierarchy-classifier",
        "classifier_result_file": "bert_opp115_hierarchy_classification_results.json",
        "colab_classification_summary_pattern": (
            "colab_bert_hierarchy_classification_{MODE}.json"
        ),
        "category_count": 10,
        "attribute_head_count": 20,
        "fine_grained_label_count": 138,
        "categories": list(HIGH_LEVEL_CATEGORIES),
        "attribute_heads": list(ATTRIBUTE_HEADS),
        "hierarchy_schema_version": hierarchy_schema.schema_version,
        "hierarchy_schema_sha256": hierarchy_schema.schema_sha256,
        "hierarchy_schema": hierarchy_manifest,
        "attribute_value_vocabulary_scope": "65 training policies only",
        "held_out_unknown_attribute_values": data_summary[
            "held_out_unknown_attribute_values"
        ],
        "full_model": {
            "name": "google-bert/bert-base-uncased",
            "revision": "86b5e0934494bd15c9632b12f734a8a67f723594",
            "model_type": "bert",
            "tokenizer_max_length": 512,
            "license_notice": (
                "See the upstream google-bert/bert-base-uncased model card for licensing."
            ),
        },
        "smoke_model": {
            "name": "google/bert_uncased_L-2_H-128_A-2",
            "revision": "30b0a37ccaaa32f332884b96992754e246e48c5f",
            "model_type": "bert",
        },
        "pretraining_objective": "optional continued domain-adaptive MLM without NSP",
        "archive_layout": "project files at root; canonical data under data/opp115",
        "annotation_csv_files": annotation_count,
        "sanitized_policy_files": policy_count,
        "annotation_rows": annotation_rows,
        "grouped_policy_segments": data_summary["segments"],
        "multi_label_segments": data_summary["multi_label_segments"],
        "segment_aggregation": (
            "union annotations by (policy filename stem, segment_id)"
        ),
        "whole_policy_split": {
            "training": 65,
            "evaluation": 50,
            "train_policy_ids": list(train_policy_ids),
            "eval_policy_ids": list(eval_policy_ids),
        },
        "segment_split": {
            "training": data_summary["train_segments"],
            "evaluation": data_summary["eval_segments"],
        },
        "primary_metric": "hierarchical_macro_f1",
        "target_hierarchical_macro_f1": 0.96,
        "pooling_strategy": "bert_cls_dense_tanh",
        "classifier_dropout": 0.15,
        "checkpoint_serialization": "safetensors",
        "positive_class_weighting": {
            "formula": "sqrt((negative + 1) / (positive + 1))",
            "minimum": 1.0,
            "maximum": 10.0,
            "attribute_scope": "applicable training rows only",
        },
        "full_training_configuration": {
            "max_length": 384,
            "batch_size": 8,
            "gradient_accumulation_steps": 4,
            "effective_batch_size": 32,
            "epochs": 5,
            "learning_rate": 2.5e-5,
            "padding": "dynamic_to_batch_multiple_of_8",
        },
        "reported_metric_groups": (
            "category, category-gated fine-grained, and independent attribute heads"
        ),
        "classification_threshold": 0.5,
        "files": file_records,
        "excluded_local_only_content": list(EXCLUDED_LOCAL_ONLY_CONTENT),
    }
    tree_digest_input = "".join(
        f"{record['sha256']}  {record['bytes']}  {record['path']}\n"
        for record in sorted(file_records, key=lambda value: str(value["path"]))
    ).encode("utf-8")
    manifest["payload_tree_sha256"] = sha256_bytes(tree_digest_input)
    manifest_bytes = (
        json.dumps(manifest, indent=2, sort_keys=True).encode("utf-8") + b"\n"
    )
    ROOT_MANIFEST_PATH.write_bytes(manifest_bytes)

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    temporary_archive = ARCHIVE_PATH.with_suffix(".zip.incomplete")
    with zipfile.ZipFile(
        temporary_archive,
        mode="w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=9,
        allowZip64=True,
    ) as archive:
        for item in inputs:
            archive.writestr(
                deterministic_zip_info(item.archive_name), item.source.read_bytes()
            )
        archive.writestr(
            deterministic_zip_info("workspace_manifest.json"), manifest_bytes
        )

    temporary_archive.replace(ARCHIVE_PATH)
    archive_digest = sha256_file(ARCHIVE_PATH)
    sidecar = {
        **manifest,
        "archive_file": ARCHIVE_PATH.name,
        "archive_bytes": ARCHIVE_PATH.stat().st_size,
        "archive_sha256": archive_digest,
    }
    MANIFEST_PATH.write_text(
        json.dumps(sidecar, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    SHA256_PATH.write_text(
        f"{archive_digest}  {ARCHIVE_PATH.name}\n", encoding="ascii"
    )
    return sidecar


def validate_workspace(sidecar: dict[str, object]) -> None:
    expected_records = {
        str(record["path"]): record
        for record in sidecar["files"]  # type: ignore[index]
    }
    with zipfile.ZipFile(ARCHIVE_PATH, "r") as archive:
        archive_names = archive.namelist()
        if len(archive_names) != len(set(archive_names)):
            raise ValueError("ZIP contains duplicate member names")
        for name in archive_names:
            normalized_archive_name(name)
        if set(archive_names) != set(expected_records) | {"workspace_manifest.json"}:
            raise ValueError("ZIP contents do not match the workspace manifest")
        for name, record in expected_records.items():
            data = archive.read(name)
            if len(data) != record["bytes"] or sha256_bytes(data) != record["sha256"]:
                raise ValueError(f"ZIP member failed verification: {name}")
        embedded = json.loads(archive.read("workspace_manifest.json"))
        if embedded.get("hierarchy_schema_sha256") != sidecar["hierarchy_schema_sha256"]:
            raise ValueError("Embedded hierarchy schema hash is inconsistent")
        if embedded.get("payload_tree_sha256") != sidecar["payload_tree_sha256"]:
            raise ValueError("Embedded payload-tree hash is inconsistent")

    digest_line = SHA256_PATH.read_text(encoding="ascii").strip()
    if digest_line != f"{sidecar['archive_sha256']}  {ARCHIVE_PATH.name}":
        raise ValueError("SHA-256 sidecar is inconsistent")


def main() -> None:
    sidecar = build_workspace()
    validate_workspace(sidecar)
    print(ARCHIVE_PATH)
    print(MANIFEST_PATH)
    print(SHA256_PATH)
    print(
        f"files={len(sidecar['files']) + 1} "
        f"bytes={sidecar['archive_bytes']} sha256={sidecar['archive_sha256']}"
    )


if __name__ == "__main__":
    main()
