"""Contract and integrity tests for the BERT OPP-115 Colab bundle."""

from __future__ import annotations

import ast
import hashlib
import json
import unittest
import zipfile
from pathlib import Path, PurePosixPath


PROJECT_ROOT = Path(__file__).resolve().parents[1]
NOTEBOOK_PATH = PROJECT_ROOT / "bert_opp115_colab.ipynb"
MIGRATION_DIR = PROJECT_ROOT / "colab_migration"
if not (MIGRATION_DIR / "bert_opp115_colab_workspace.zip").is_file():
    # The distributable target folder keeps the archive beside the notebook.
    MIGRATION_DIR = PROJECT_ROOT
ARCHIVE_PATH = MIGRATION_DIR / "bert_opp115_colab_workspace.zip"
MANIFEST_PATH = (
    MIGRATION_DIR / "bert_opp115_colab_workspace.manifest.json"
)
SHA256_PATH = MIGRATION_DIR / "bert_opp115_colab_workspace.zip.sha256"

EXPECTED_HIERARCHY_SCHEMA_SHA256 = (
    "90627a25efe47a217e03a2f09431b3256bc254867cd8f9aee675a1eafbb93b9b"
)
EXPECTED_CATEGORIES = (
    "First Party Collection/Use",
    "Third Party Sharing/Collection",
    "User Choice/Control",
    "Data Retention",
    "Data Security",
    "International and Specific Audiences",
    "Do Not Track",
    "Policy Change",
    "Access, Edit and Deletion",
    "Other",
)
EXPECTED_ATTRIBUTE_HEADS = (
    "does_does_not",
    "collection_mode",
    "action_first_party",
    "identifiability",
    "personal_information_type",
    "purpose",
    "user_type",
    "choice_type",
    "choice_scope",
    "third_party_entity",
    "action_third_party",
    "access_type",
    "access_scope",
    "retention_period",
    "retention_purpose",
    "security_measure",
    "change_type",
    "notification_type",
    "do_not_track_policy",
    "audience_type",
)


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


class BERTColabBundleTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.notebook = json.loads(NOTEBOOK_PATH.read_text(encoding="utf-8"))
        cls.code_sources = []
        cls.all_sources = []
        for cell in cls.notebook["cells"]:
            source = cell.get("source", "")
            if isinstance(source, list):
                source = "".join(source)
            else:
                source = str(source)
            cls.all_sources.append(source)
            if cell.get("cell_type") == "code":
                cls.code_sources.append(source)
        cls.all_source = "\n".join(cls.all_sources)
        cls.code_source = "\n".join(cls.code_sources)
        cls.manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
        cls.manifest_paths = {
            record["path"] for record in cls.manifest["files"]
        }

    def test_notebook_is_gpu_ready_and_requires_the_hierarchy_module(self) -> None:
        self.assertEqual(self.notebook["nbformat"], 4)
        self.assertEqual(self.notebook["metadata"]["accelerator"], "GPU")
        self.assertEqual(
            self.notebook["metadata"]["colab"]["name"],
            "bert_opp115_colab.ipynb",
        )
        required_files = {
            "bert_opp115_colab.ipynb",
            "bert_opp115_pretraining.py",
            "bert_opp115_classification.py",
            "opp115_hierarchy.py",
            "tests/test_opp115_hierarchy.py",
            "tests/test_bert_opp115_classification.py",
            "tests/test_bert_colab_bundle.py",
        }
        self.assertTrue(required_files <= self.manifest_paths)
        self.assertIn('"opp115_hierarchy.py"', self.code_source)
        self.assertIn("from opp115_hierarchy import", self.code_source)
        self.assertIn("bert_opp115_pretraining.py", self.code_source)
        self.assertIn("bert_opp115_classification.py", self.code_source)

    def test_full_is_default_and_smoke_is_an_explicit_local_override(self) -> None:
        self.assertEqual(self.manifest["default_mode"], "full")
        self.assertIn('MODE = "full"', self.code_source)
        self.assertIn('BERT_OPP115_MODE_OVERRIDE', self.code_source)
        self.assertIn('local_mode_override not in {"smoke", "full"}', self.code_source)
        self.assertIn('if MODE == "smoke"', self.code_source)
        self.assertIn('"--max-train-examples", "8"', self.code_source)
        self.assertIn('"--max-eval-examples", "32"', self.code_source)
        self.assertIn('"--max-steps", "1"', self.code_source)
        self.assertIn(
            'MODEL_NAME = "google-bert/bert-base-uncased"',
            self.code_source,
        )
        self.assertIn(
            'MODEL_REVISION = "86b5e0934494bd15c9632b12f734a8a67f723594"',
            self.code_source,
        )
        self.assertIn(
            'RUN_NAME = "opp115_bert_base_hierarchy_v1"',
            self.code_source,
        )
        self.assertIn('RUN_PRETRAINING = False', self.code_source)
        expected_full_settings = (
            '"max_length": 64 if MODE == "smoke" else 384',
            '"epochs": 5',
            '"gradient_accumulation_steps": 4',
            '"learning_rate": 2.5e-5',
            '"classifier_dropout": 0.15',
            '"positive_weight_power": 0.5',
            '"max_positive_weight": 10.0',
            "TARGET_HIERARCHICAL_MACRO_F1 = 0.96",
            '"target_hierarchical_macro_f1": TARGET_HIERARCHICAL_MACRO_F1',
        )
        for expected in expected_full_settings:
            with self.subTest(expected=expected):
                self.assertIn(expected, self.code_source)

        self.assertEqual(
            self.manifest["full_model"],
            {
                "model_type": "bert",
                "name": "google-bert/bert-base-uncased",
                "revision": "86b5e0934494bd15c9632b12f734a8a67f723594",
                "tokenizer_max_length": 512,
                "license_notice": (
                    "See the upstream google-bert/bert-base-uncased model card for licensing."
                ),
            },
        )
        self.assertEqual(
            self.manifest["smoke_model"],
            {
                "model_type": "bert",
                "name": "google/bert_uncased_L-2_H-128_A-2",
                "revision": "30b0a37ccaaa32f332884b96992754e246e48c5f",
            },
        )

    def test_hierarchy_contract_and_training_only_schema_are_frozen(self) -> None:
        manifest = self.manifest
        schema = manifest["hierarchy_schema"]
        self.assertEqual(manifest["task"], "hierarchical_fine_grained_segment_classification")
        self.assertEqual(manifest["category_count"], 10)
        self.assertEqual(manifest["attribute_head_count"], 20)
        self.assertEqual(manifest["fine_grained_label_count"], 138)
        self.assertEqual(tuple(manifest["categories"]), EXPECTED_CATEGORIES)
        self.assertEqual(tuple(manifest["attribute_heads"]), EXPECTED_ATTRIBUTE_HEADS)
        self.assertEqual(
            manifest["attribute_value_vocabulary_scope"],
            "65 training policies only",
        )
        self.assertEqual(
            manifest["hierarchy_schema_sha256"],
            EXPECTED_HIERARCHY_SCHEMA_SHA256,
        )
        self.assertEqual(
            schema["schema_sha256"], EXPECTED_HIERARCHY_SCHEMA_SHA256
        )
        self.assertEqual(schema["category_count"], 10)
        self.assertEqual(schema["attribute_head_count"], 20)
        self.assertEqual(schema["flattened_attribute_value_count"], 138)
        self.assertEqual(tuple(schema["high_level_categories"]), EXPECTED_CATEGORIES)
        self.assertEqual(tuple(schema["attribute_heads"]), EXPECTED_ATTRIBUTE_HEADS)
        self.assertEqual(
            sum(
                len(schema["attribute_value_vocabulary"][head])
                for head in EXPECTED_ATTRIBUTE_HEADS
            ),
            138,
        )
        self.assertEqual(
            manifest["held_out_unknown_attribute_values"],
            {"do_not_track_policy=honored": 1},
        )

        required_notebook_literals = (
            f'"{EXPECTED_HIERARCHY_SCHEMA_SHA256}"',
            "EXPECTED_CATEGORY_COUNT = 10",
            "EXPECTED_ATTRIBUTE_HEAD_COUNT = 20",
            "EXPECTED_FINE_GRAINED_LABEL_COUNT = 138",
            "derive_hierarchy_schema(annotations_dir, TRAIN_POLICY_IDS)",
        )
        for expected in required_notebook_literals:
            with self.subTest(expected=expected):
                self.assertIn(expected, self.code_source)

    def test_exact_whole_policy_and_segment_splits_are_enforced(self) -> None:
        split = self.manifest["whole_policy_split"]
        train_ids = split["train_policy_ids"]
        eval_ids = split["eval_policy_ids"]
        self.assertEqual(split["training"], 65)
        self.assertEqual(split["evaluation"], 50)
        self.assertEqual(len(train_ids), 65)
        self.assertEqual(len(eval_ids), 50)
        self.assertFalse(set(train_ids) & set(eval_ids))
        self.assertEqual(
            self.manifest["hierarchy_schema"]["training_policy_ids"], train_ids
        )
        self.assertEqual(
            self.manifest["segment_split"],
            {"training": 2352, "evaluation": 1440},
        )
        self.assertEqual(self.manifest["grouped_policy_segments"], 3792)
        self.assertEqual(self.manifest["annotation_rows"], 23194)
        self.assertEqual(self.manifest["annotation_csv_files"], 115)
        self.assertEqual(self.manifest["sanitized_policy_files"], 115)
        self.assertIn("train_count=65, eval_count=50", self.code_source)
        self.assertIn('summary.get("train_segments") != 2352', self.code_source)
        self.assertIn('summary.get("eval_segments") != 1440', self.code_source)
        self.assertIn('summary.get("train_eval_policy_ids_disjoint") is not True', self.code_source)

    def test_output_names_and_gated_metric_contract_are_explicit(self) -> None:
        manifest = self.manifest
        self.assertEqual(
            manifest["classifier_output_directory"],
            "bert-opp115-hierarchy-classifier",
        )
        self.assertEqual(
            manifest["classifier_result_file"],
            "bert_opp115_hierarchy_classification_results.json",
        )
        self.assertEqual(
            manifest["colab_classification_summary_pattern"],
            "colab_bert_hierarchy_classification_{MODE}.json",
        )
        self.assertEqual(manifest["primary_metric"], "hierarchical_macro_f1")
        self.assertEqual(manifest["classification_threshold"], 0.5)
        self.assertEqual(
            manifest["reported_metric_groups"],
            "category, category-gated fine-grained, and independent attribute heads",
        )

        required_notebook_text = (
            'RUN_ROOT / "bert-opp115-hierarchy-classifier"',
            'path / "hierarchy_heads.safetensors"',
            'f"colab_bert_hierarchy_classification_{MODE}.json"',
            'RUN_ROOT / "bert_hierarchy_classification.complete.json"',
            '"bert_opp115_hierarchy_classification_results.json"',
            'results.get("primary_metric") != "hierarchical_macro_f1"',
            'fine.get("primary_metric") != "fine_grained_macro_f1"',
            'results.get("independent_attribute_heads", {})',
            'metrics["fine_grained"]["fine_grained_macro_f1"]',
            "Gated fine-grained macro-F1",
        )
        for expected in required_notebook_text:
            with self.subTest(expected=expected):
                self.assertIn(expected, self.code_source)

    def test_superseded_flat_twenty_label_taxonomy_is_not_required(self) -> None:
        stale_notebook_tokens = (
            "opp115_20label_taxonomy",
            "bert-opp115-20label-classifier",
            "bert_opp115_20label_classification_results",
            "colab_bert_20label_classification",
            "hierarchical_20label_segment_classification",
        )
        for stale in stale_notebook_tokens:
            with self.subTest(stale=stale):
                self.assertNotIn(stale, self.code_source)

        self.assertNotIn("opp115_20label_taxonomy.py", self.manifest_paths)
        self.assertNotIn(
            "tests/test_opp115_20label_taxonomy.py", self.manifest_paths
        )
        self.assertFalse(
            any("20label" in path.casefold() for path in self.manifest_paths)
        )

    def test_archive_manifest_and_sha256_sidecar_are_consistent(self) -> None:
        manifest = self.manifest
        self.assertEqual(manifest["archive_file"], ARCHIVE_PATH.name)
        self.assertEqual(manifest["archive_bytes"], ARCHIVE_PATH.stat().st_size)
        archive_digest = _sha256_file(ARCHIVE_PATH)
        self.assertEqual(manifest["archive_sha256"], archive_digest)
        self.assertEqual(
            SHA256_PATH.read_text(encoding="ascii").strip(),
            f"{archive_digest}  {ARCHIVE_PATH.name}",
        )

        records = manifest["files"]
        records_by_path = {record["path"]: record for record in records}
        self.assertEqual(len(records_by_path), len(records))
        tree_digest_input = "".join(
            f"{record['sha256']}  {record['bytes']}  {record['path']}\n"
            for record in sorted(records, key=lambda value: value["path"])
        ).encode("utf-8")
        self.assertEqual(
            manifest["payload_tree_sha256"], _sha256_bytes(tree_digest_input)
        )

        with zipfile.ZipFile(ARCHIVE_PATH, "r") as archive:
            self.assertIsNone(archive.testzip())
            archive_names = archive.namelist()
            self.assertEqual(len(archive_names), len(set(archive_names)))
            self.assertEqual(
                set(archive_names),
                set(records_by_path) | {"workspace_manifest.json"},
            )
            for name in archive_names:
                member_path = PurePosixPath(name)
                self.assertFalse(member_path.is_absolute(), name)
                self.assertNotIn("..", member_path.parts, name)
                self.assertNotIn("\\", name)

            for name, record in records_by_path.items():
                data = archive.read(name)
                with self.subTest(member=name):
                    self.assertEqual(len(data), record["bytes"])
                    self.assertEqual(_sha256_bytes(data), record["sha256"])

            embedded = json.loads(archive.read("workspace_manifest.json"))

        sidecar_only_keys = {"archive_file", "archive_bytes", "archive_sha256"}
        manifest_core = {
            key: value
            for key, value in manifest.items()
            if key not in sidecar_only_keys
        }
        self.assertEqual(embedded, manifest_core)
        self.assertEqual(
            embedded["hierarchy_schema_sha256"],
            EXPECTED_HIERARCHY_SCHEMA_SHA256,
        )
        self.assertIn("opp115_hierarchy.py", records_by_path)
        self.assertNotIn("opp115_20label_taxonomy.py", records_by_path)

    def test_every_code_cell_parses_as_python(self) -> None:
        for index, cell in enumerate(self.notebook["cells"]):
            if cell.get("cell_type") != "code":
                continue
            source = cell.get("source", "")
            if isinstance(source, list):
                source = "".join(source)
            with self.subTest(cell=index):
                ast.parse(source)


if __name__ == "__main__":
    unittest.main()
